#!/bin/bash

while true
do
     echo Hello Embedfire >> /tmp/hello.log
     sleep 3
done



